<h2>Wiki jGallery</h2>
Requisitos? Recursos? Instalação? Exemplos? <a href="http://wiki.github.com/igorescobar/jGallery/">clique aqui</a>.